//
//  TeamCard.swift
//  HelloWorld
//
//  Created by Mobile on 5/15/26.
//

import SwiftUI

struct TeamCard: View {
    
    let team: Team
    
    var body: some View {
        
        ZStack {
            
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.pink)
            
            Text(team.name)
                .font(.headline)
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .padding()
        }
        .frame(height: 80)
    }
}
