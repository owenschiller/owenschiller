//
//  SoccerTrackerApp.swift
//  HelloWorld
//
//  Created by Mobile on 5/15/26.
//
import SwiftUI

@main
struct SoccerTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
