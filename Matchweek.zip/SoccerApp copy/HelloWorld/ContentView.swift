import SwiftUI

struct ContentView: View {
    
    @State private var teams = sampleTeams
    
    var body: some View {
        
        TabView {
            
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            
            TeamsView(teams: $teams)
                .tabItem {
                    Label("Teams", systemImage: "soccerball")
                }
            
            FavoritesView(teams: $teams)
                .tabItem {
                    Label("Favorites", systemImage: "star.fill")
                }
            
            RankingsView(teams: teams)
                .tabItem {
                    Label("Rankings", systemImage: "chart.bar.fill")
                }
        }
    }
}

#Preview {
    ContentView()
}
