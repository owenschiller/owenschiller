import SwiftUI

struct TeamDetailView: View {
    
    @Environment(\.dismiss) var dismiss
    
    @Binding var team: Team
    
    var body: some View {
        
        VStack(spacing: 20) {

            ScrollView {

                VStack(spacing: 20) {

                    Text(team.name)
                        .font(.largeTitle)
                        .bold()

                    Image("stadium")
                        .resizable()
                        .scaledToFill()
                        .frame(height: 200)
                        .frame(maxWidth: .infinity)
                        .clipped()
                        .cornerRadius(12)

                    Text("Stadium: \(team.stadium)")
                        .font(.headline)

                    GroupBox("Last 5 Games") {

                        VStack(alignment: .leading) {

                            Text(team.lastFive.joined(separator: "  "))

                            Text("Form Points: \(team.formPoints)")
                                .font(.headline)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    GroupBox("Top Players") {

                        VStack(alignment: .leading, spacing: 8) {

                            ForEach(team.topPlayers, id: \.self) { player in
                                Text(player)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    Button {
                        team.isFavorite = false
                        dismiss()
                    } label: {
                        Text("Remove from Favorites")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(12)
                    }
                }
                .padding(.horizontal)
                .padding(.vertical)
            }
        }
    }
}

#Preview {
    TeamDetailView(team: .constant(sampleTeams[0]))
}
