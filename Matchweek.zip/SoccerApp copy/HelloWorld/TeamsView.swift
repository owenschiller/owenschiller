//
//  TeamsView.swift
//  HelloWorld
//
//  Created by Mobile on 3/27/26.
//
import SwiftUI

struct TeamsView: View {
    
    @Binding var teams: [Team]
    
    var body: some View {
        
        NavigationStack {
            
            List {
                
                ForEach($teams) { $team in
                    
                    HStack {
                        
                        VStack(alignment: .leading) {
                            
                            Text(team.name)
                                .font(.headline)
                            
                            Text(team.stadium)
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                        
                        Spacer()
                        
                        Button {
                            
                            team.isFavorite.toggle()
                            
                        } label: {
                            
                            Image(systemName:
                                    team.isFavorite
                                  ? "heart.fill"
                                  : "heart"
                            )
                            .foregroundColor(.red)
                            .font(.title2)
                        }
                    }
                    .padding(.vertical, 5)
                }
            }
            .navigationTitle("Premier League Teams")
        }
    }
}

#Preview {
    
    TeamsView(
        teams: .constant(sampleTeams)
    )
}
