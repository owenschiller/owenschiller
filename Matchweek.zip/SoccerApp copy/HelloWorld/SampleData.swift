//
//  SampleData.swift
//  HelloWorld
//
//  Created by Mobile on 5/15/26.
//

import Foundation

let sampleTeams = [
    
    Team(
        name: "Arsenal",
        stadium: "Emirates Stadium",
        isFavorite: false,
        lastFive: ["W", "W", "W", "W", "W"],
        topPlayers: ["Bukayo Saka", "Martin Ødegaard", "Declan Rice"]
    ),
    
    Team(
        name: "Man City",
        stadium: "Etihad Stadium",
        isFavorite: false,
        lastFive: ["D", "W", "W", "D", "L"],
        topPlayers: ["Erling Haaland", "Phil Foden", "Rodri"]
    ),
    
    Team(
        name: "Man United",
        stadium: "Old Trafford",
        isFavorite: false,
        lastFive: ["W", "W", "D", "W", "W"],
        topPlayers: ["Bruno Fernandes", "Kobbie Mainoo", "Alejandro Garnacho"]
    ),
    
    Team(
        name: "Chelsea",
        stadium: "Stamford Bridge",
        isFavorite: false,
        lastFive: ["L", "L", "D", "W", "L"],
        topPlayers: ["Cole Palmer", "Enzo Fernández", "Moisés Caicedo"]
    ),
    
    Team(
        name: "Aston Villa",
        stadium: "Villa Park",
        isFavorite: false,
        lastFive: ["L", "L", "D", "W", "W"],
        topPlayers: ["Ollie Watkins", "Morgan Rogers", "Emiliano Martínez"]
    ),
    
    Team(
        name: "Liverpool",
        stadium: "Anfield",
        isFavorite: false,
        lastFive: ["W", "L", "D", "L", "D"],
        topPlayers: ["Mohamed Salah", "Virgil van Dijk", "Alexis Mac Allister"]
    ),
    
    Team(
        name: "Bournemouth",
        stadium: "Vitality Stadium",
        isFavorite: false,
        lastFive: ["D", "W", "W", "D", "D"],
        topPlayers: ["Justin Kluivert", "Antoine Semenyo", "Dean Huijsen"]
    ),
    
    Team(
        name: "Sunderland",
        stadium: "Stadium of Light",
        isFavorite: false,
        lastFive: ["L", "D", "D", "W", "W"],
        topPlayers: ["Jobe Bellingham", "Dan Neil", "Wilson Isidor"]
    ),
    
    Team(
        name: "Brighton",
        stadium: "Amex Stadium",
        isFavorite: false,
        lastFive: ["W", "L", "W", "L", "L"],
        topPlayers: ["Kaoru Mitoma", "João Pedro", "Carlos Baleba"]
    ),
    
    Team(
        name: "Brentford",
        stadium: "Gtech Community Stadium",
        isFavorite: false,
        lastFive: ["L", "W", "L", "D", "D"],
        topPlayers: ["Bryan Mbeumo", "Yoane Wissa", "Nathan Collins"]
    ),
    
    Team(
        name: "Fulham",
        stadium: "Craven Cottage",
        isFavorite: false,
        lastFive: ["W", "L", "L", "D", "W"],
        topPlayers: ["Antonee Robinson", "Alex Iwobi", "Raúl Jiménez"]
    ),
    
    Team(
        name: "Newcastle",
        stadium: "St James' Park",
        isFavorite: false,
        lastFive: ["L", "W", "D", "W", "L"],
        topPlayers: ["Alexander Isak", "Bruno Guimarães", "Anthony Gordon"]
    ),
    
    Team(
        name: "Everton",
        stadium: "Goodison Park",
        isFavorite: false,
        lastFive: ["L", "D", "D", "L", "L"],
        topPlayers: ["Jarrad Branthwaite", "Iliman Ndiaye", "Jordan Pickford"]
    ),
    
    Team(
        name: "Leeds",
        stadium: "Elland Road",
        isFavorite: false,
        lastFive: ["D", "W", "D", "W", "L"],
        topPlayers: ["Daniel James", "Ethan Ampadu", "Joel Piroe"]
    ),
    
    Team(
        name: "Crystal Palace",
        stadium: "Selhurst Park",
        isFavorite: false,
        lastFive: ["L", "D", "L", "D", "L"],
        topPlayers: ["Eberechi Eze", "Marc Guéhi", "Adam Wharton"]
    ),
    
    Team(
        name: "Nottingham Forest",
        stadium: "City Ground",
        isFavorite: false,
        lastFive: ["W", "W", "D", "L", "D"],
        topPlayers: ["Morgan Gibbs-White", "Chris Wood", "Murillo"]
    ),
    
    Team(
        name: "Tottenham",
        stadium: "Tottenham Hotspur Stadium",
        isFavorite: false,
        lastFive: ["W", "D", "D", "L", "W"],
        topPlayers: ["Son Heung-min", "James Maddison", "Cristian Romero"]
    ),
    
    Team(
        name: "West Ham",
        stadium: "London Stadium",
        isFavorite: false,
        lastFive: ["W", "L", "L", "L", "W"],
        topPlayers: ["Jarrod Bowen", "Mohammed Kudus", "Lucas Paquetá"]
    ),
    
    Team(
        name: "Burnley",
        stadium: "Turf Moor",
        isFavorite: false,
        lastFive: ["L", "L", "D", "L", "D"],
        topPlayers: ["Josh Brownhill", "Zeki Amdouni", "Maxime Estève"]
    ),
    
    Team(
        name: "Wolves",
        stadium: "Molineux Stadium",
        isFavorite: false,
        lastFive: ["L", "D", "L", "D", "D"],
        topPlayers: ["Matheus Cunha", "Rayan Aït-Nouri", "João Gomes"]
    )
]
