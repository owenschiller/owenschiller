//
//  Team.swift
//  HelloWorld
//
//  Created by Mobile on 3/27/26.
//
import Foundation

struct Team: Identifiable {
    
    let id = UUID()
    
    let name: String
    
    let stadium: String
    
    var isFavorite: Bool
    
    let lastFive: [String]
    
    let topPlayers: [String]
    
    var formPoints: Int {
        
        var points = 0
        
        for result in lastFive {
            
            if result == "W" {
                points += 3
            }
            
            else if result == "D" {
                points += 1
            }
        }
        
        return points
    }
}
