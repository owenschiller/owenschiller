//
//  FavoritesView.swift
//  HelloWorld
//
//  Created by Mobile on 3/27/26.
//

import SwiftUI

struct FavoritesView: View {
    
    @Binding var teams: [Team]
    
    var favoriteTeams: [Team] {
        
        teams.filter { $0.isFavorite }
    }
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        
        NavigationStack {
            
            ScrollView {
                
                VStack(alignment: .leading, spacing: 20) {
                    
                    
                    LazyVGrid(columns: columns, spacing: 15) {
                        
                        ForEach($teams) { $team in
                            
                            if team.isFavorite {
                                
                                NavigationLink(destination: TeamDetailView(team: $team)) {
                                    
                                    HStack {
                                        Text(team.name)
                                            .font(.headline)
                                        
                                        Spacer()
                                        
                                        Image(systemName: "chevron.right")
                                            .font(.headline)
                                    }
                                    .foregroundColor(.white)
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 80)
                                    .background(Color.red)
                                    .cornerRadius(15)
                                }
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Your Favorite Teams")
        }
    }
}

#Preview {
    
    FavoritesView(teams: .constant(sampleTeams))
}
