//
//  RankingsView.swift
//  HelloWorld
//
//  Created by Mobile on 5/15/26.
//

import SwiftUI

struct RankingsView: View {
    
    let teams: [Team]
    
    var rankedTeams: [Team] {
        
        teams
            .filter { $0.isFavorite }
            .sorted(by: { team1, team2 in
                team1.formPoints > team2.formPoints
            })
    }
    
    var body: some View {
        
        NavigationStack {
            
            List {
                
                ForEach(
                    Array(rankedTeams.enumerated()),
                    id: \.element.id
                ) { index, team in
                    
                    HStack(spacing: 15) {
                        
                        Text("#\(index + 1)")
                            .font(.headline)
                        
                        VStack(alignment: .leading) {
                            
                            Text(team.name)
                                .font(.headline)
                            
                            HStack {
                                
                                ForEach(team.lastFive, id: \.self) { result in
                                    
                                    Text(result)
                                        .font(.caption)
                                        .padding(6)
                                        .background(
                                            result == "W"
                                            ? Color.green
                                            : result == "D"
                                            ? Color.gray
                                            : Color.red
                                        )
                                        .foregroundColor(.white)
                                        .clipShape(Circle())
                                }
                            }
                        }
                        
                        Spacer()
                        
                        Text("\(team.formPoints) pts")
                            .bold()
                    }
                    .padding(.vertical, 5)
                }
            }
            .navigationTitle("Form Rankings")
        }
    }
}

#Preview {
    
    RankingsView(
        teams: sampleTeams
    )
}
