//
//  HomeView.swift
//  HelloWorld
//
//  Created by Mobile on 3/27/26.
//

import SwiftUI

struct HomeView: View {
    
    var body: some View {
        
        NavigationStack {
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Welcome to Matchweek!")
                            .font(.title)
                            .bold()
                        
                        Text("Matchweek is an app you can use to track your favorite Premier League teams, view recent form, and compare rankings.")
                            .foregroundColor(.secondary)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(15)
                    
                    Text("Latest Soccer News")
                        .font(.title2)
                        .bold()
                    
                    VStack(spacing: 12) {
                        NewsCard(text: "Arsenal finish the season as Premier League champions after an impressive title-winning campaign.")
                        NewsCard(text: "Chelsea look to regroup and push higher up the table next season.")
                        NewsCard(text: "Tottenham narrowly avoid relegation after a difficult season near the bottom of the standings.")
                        NewsCard(text: "Coventry City, Ipswich Town, and Hull City will join the Premier League next season after earning promotion.")
                        NewsCard(text: "West Ham United, Burnley, and Wolverhampton Wanderers have been relegated to the Championship for next season.")
                    }
                }
                .padding()
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}

struct NewsCard: View {
    
    let text: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("News Update")
                .font(.caption)
                .foregroundColor(.secondary)
            
            Text(text)
                .font(.body)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

#Preview {
    HomeView()
}
